package com.askaa.asisten

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val items: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val bubble: TextView = view.findViewById(R.id.bubble)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = items[position]
        val isUser = msg.role == "user"

        holder.bubble.text = msg.text
        holder.bubble.setBackgroundResource(
            if (isUser) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai
        )

        val params = holder.bubble.layoutParams as FrameLayout.LayoutParams
        params.gravity = if (isUser) Gravity.END else Gravity.START
        holder.bubble.layoutParams = params

        // Tahan lama pesan untuk menyalin teksnya
        holder.bubble.setOnLongClickListener {
            val context = holder.bubble.context
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("chat", msg.text))
            Toast.makeText(context, "Disalin", Toast.LENGTH_SHORT).show()
            true
        }
    }
}
