package com.askaa.asisten

/** role: "user" atau "assistant". */
data class ChatMessage(val role: String, val text: String)
