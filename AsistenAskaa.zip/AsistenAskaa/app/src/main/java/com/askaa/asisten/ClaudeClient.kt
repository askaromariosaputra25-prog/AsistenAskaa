package com.askaa.asisten

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ApiException(message: String) : Exception(message)

/** Panggilan langsung ke Messages API Anthropic. Dipanggil dari thread belakang, bukan dari UI. */
object ClaudeClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val ANTHROPIC_VERSION = "2023-06-01"

    const val MODEL_HAIKU = "claude-haiku-5-5"
    const val MODEL_SONNET = "claude-sonnet-5-5"

    private const val SYSTEM_PROMPT =
        "Kamu adalah Asisten Askaa, asisten AI yang ramah dan membantu. " +
            "Jawab dalam bahasa yang dipakai pengguna, jelas, dan tidak bertele-tele."

    private class Raw(val code: Int, val body: String)

    fun send(apiKey: String, model: String, history: List<ChatMessage>): String {
        val payload = buildPayload(model, history).toString()

        val res = try {
            post(apiKey, payload)
        } catch (e: IOException) {
            throw ApiException("Tidak bisa terhubung. Cek koneksi internet kamu.")
        }

        if (res.code !in 200..299) {
            throw ApiException(friendlyError(res.code, res.body))
        }

        val content = JSONObject(res.body).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.getString("text"))
        }
        return sb.toString().trim().ifEmpty { "(jawaban kosong)" }
    }

    private fun buildPayload(model: String, history: List<ChatMessage>): JSONObject {
        val messages = JSONArray()
        history.forEach { msg ->
            messages.put(JSONObject().put("role", msg.role).put("content", msg.text))
        }
        return JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", SYSTEM_PROMPT)
            .put("messages", messages)
    }

    private fun post(apiKey: String, payload: String): Raw {
        val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", ANTHROPIC_VERSION)

            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Raw(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun friendlyError(code: Int, body: String): String {
        val serverMsg = try {
            JSONObject(body).getJSONObject("error").getString("message")
        } catch (e: Exception) {
            ""
        }
        return when (code) {
            401, 403 -> "API key salah atau tidak punya akses. Cek lagi di pengaturan."
            429 -> "Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi."
            else -> "Gagal ($code). $serverMsg".trim()
        }
    }
}
