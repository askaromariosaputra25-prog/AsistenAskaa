package com.askaa.asisten

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.askaa.asisten.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.keyInput.setText(Prefs.getKey(this) ?: "")
        binding.modelGroup.check(
            if (Prefs.getModel(this) == ClaudeClient.MODEL_SONNET) R.id.modelSonnet else R.id.modelHaiku
        )

        binding.saveButton.setOnClickListener {
            val key = binding.keyInput.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "API key masih kosong", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val model = if (binding.modelGroup.checkedRadioButtonId == R.id.modelSonnet) {
                ClaudeClient.MODEL_SONNET
            } else {
                ClaudeClient.MODEL_HAIKU
            }
            Prefs.saveKey(this, key)
            Prefs.saveModel(this, model)
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.clearKeyButton.setOnClickListener {
            Prefs.clearKey(this)
            binding.keyInput.setText("")
            Toast.makeText(this, "Key dihapus", Toast.LENGTH_SHORT).show()
        }
    }
}
