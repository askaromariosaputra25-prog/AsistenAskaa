package com.askaa.asisten

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Semua data disimpan di penyimpanan privat app, hanya di HP ini. */
object Prefs {

    private const val FILE = "asisten_askaa"
    private const val KEY_API = "api_key"
    private const val KEY_MODEL = "model"
    private const val KEY_CHAT = "chat"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getKey(context: Context): String? =
        prefs(context).getString(KEY_API, null)?.takeIf { it.isNotBlank() }

    fun saveKey(context: Context, key: String) {
        prefs(context).edit().putString(KEY_API, key).apply()
    }

    fun clearKey(context: Context) {
        prefs(context).edit().remove(KEY_API).apply()
    }

    fun getModel(context: Context): String =
        prefs(context).getString(KEY_MODEL, ClaudeClient.MODEL_HAIKU) ?: ClaudeClient.MODEL_HAIKU

    fun saveModel(context: Context, model: String) {
        prefs(context).edit().putString(KEY_MODEL, model).apply()
    }

    fun saveChat(context: Context, messages: List<ChatMessage>) {
        val arr = JSONArray()
        messages.forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        prefs(context).edit().putString(KEY_CHAT, arr.toString()).apply()
    }

    fun loadChat(context: Context): List<ChatMessage> {
        val raw = prefs(context).getString(KEY_CHAT, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatMessage(o.getString("role"), o.getString("text"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
