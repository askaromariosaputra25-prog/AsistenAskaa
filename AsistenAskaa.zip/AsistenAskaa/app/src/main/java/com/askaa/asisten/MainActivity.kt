package com.askaa.asisten

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.askaa.asisten.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ChatAdapter

    private val messages = mutableListOf<ChatMessage>()
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        messages.addAll(Prefs.loadChat(this))
        adapter = ChatAdapter(messages)
        binding.chatList.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.chatList.adapter = adapter

        binding.sendButton.setOnClickListener { onSend() }
        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.clearButton.setOnClickListener { confirmClear() }

        binding.chipSummarize.setOnClickListener { fillInput(getString(R.string.prompt_summarize)) }
        binding.chipTranslate.setOnClickListener { fillInput(getString(R.string.prompt_translate)) }
        binding.chipCaption.setOnClickListener { fillInput(getString(R.string.prompt_caption)) }

        refresh()
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun fillInput(text: String) {
        binding.inputText.setText(text)
        binding.inputText.setSelection(text.length)
        binding.inputText.requestFocus()
    }

    private fun onSend() {
        if (busy) return

        val text = binding.inputText.text.toString().trim()
        if (text.isEmpty()) return

        val apiKey = Prefs.getKey(this)
        if (apiKey == null) {
            toast("Isi API key dulu di pengaturan")
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val model = Prefs.getModel(this)
        binding.inputText.setText("")
        messages.add(ChatMessage("user", text))
        refresh()
        setBusy(true)

        // Kirim sebagian riwayat terakhir saja, dan pastikan diawali pesan user
        val history = messages.takeLast(MAX_HISTORY).dropWhile { it.role != "user" }

        worker.execute {
            val result = try {
                Result.success(ClaudeClient.send(apiKey, model, history))
            } catch (e: Exception) {
                Result.failure(e)
            }
            main.post { onReply(text, result) }
        }
    }

    private fun onReply(userText: String, result: Result<String>) {
        setBusy(false)
        result
            .onSuccess { reply ->
                messages.add(ChatMessage("assistant", reply))
                refresh()
            }
            .onFailure { e ->
                // Hapus pesan yang gagal dan kembalikan teksnya ke kotak ketik
                if (messages.lastOrNull()?.role == "user") {
                    messages.removeAt(messages.lastIndex)
                }
                binding.inputText.setText(userText)
                refresh()
                toast(e.message ?: "Gagal menghubungi Claude")
            }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.sendButton.isEnabled = !value
        binding.statusText.visibility = if (value) View.VISIBLE else View.GONE
    }

    private fun refresh() {
        adapter.notifyDataSetChanged()
        if (messages.isNotEmpty()) binding.chatList.scrollToPosition(messages.size - 1)
        binding.emptyContainer.visibility = if (messages.isEmpty()) View.VISIBLE else View.GONE
        Prefs.saveChat(this, messages)
    }

    private fun confirmClear() {
        if (busy || messages.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus chat?")
            .setMessage("Semua percakapan akan dihapus dari HP ini.")
            .setPositiveButton("Hapus") { _, _ ->
                messages.clear()
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val MAX_HISTORY = 20
    }
}
