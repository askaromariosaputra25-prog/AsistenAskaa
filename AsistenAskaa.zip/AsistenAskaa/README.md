# Asisten Askaa

Aplikasi chat Android gratis yang terhubung ke Claude lewat Messages API Anthropic.

## Yang perlu disiapkan
- API key dari console.anthropic.com. Biaya API dihitung per pemakaian, terpisah dari langganan claude.ai.
- Isi key di menu pengaturan, pilih model, lalu simpan.

## Fitur
- Chat dengan Claude, dan riwayat tersimpan di HP sampai kamu hapus
- Pintasan awal: ringkas teks, terjemahkan, dan ide caption
- Tahan lama pesan untuk menyalin
- Pilih model Haiku (cepat, hemat) atau Sonnet (lebih pintar)

## Catatan
App ini gratis, tanpa iklan dan tanpa pembelian di dalam app. Biaya yang muncul hanya dari pemakaian API di akun Anthropic kamu. Kalau dibagikan ke orang lain, setiap orang perlu memakai API key-nya sendiri, atau perlu server penengah supaya key tidak ada di HP.

## Build dari HP
Buat repository `AsistenAskaa`, tambahkan `.github/workflows/build.yml`, upload `AsistenAskaa.zip`, lalu jalankan workflow Build APK.
